export default function Collection(){
    return (<h1>제품목록페이지임다</h1>)
}