export default function About(){
    return (
        <h2>Hello</h2>
    )
}