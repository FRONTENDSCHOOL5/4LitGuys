import './collection.css'

const Collection = () => {
  return (
    <section className="collectionWrapper">
      <div className='collection'>
        <div className='pic'/>
        <div className='pic'/>
      </div>
      <div className='collection'>
        <div className='pic'/>
        <div className='pic'/>
      </div>
    </section>
  )
};

export default Collection;
