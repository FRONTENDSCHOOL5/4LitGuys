import './simon.css'

const Simon = () => {
    return (
        <section className='simonWrapper'>
            <div className='simonPic'></div>
            <p className='subTitle'>
                <span className='top'>"Jem'appelleSimon, j'aimelebleuetleblanc,</span><br/>
                <span>lesrayures, lesoleil, lesfruits, lesronds, lavie, lapoésie</span><br/>
               <span className='bottom'> Marseilleetlesannées80"</span>
            </p>
            <p>Simon Porte Jacquemus</p>
        </section>
    )
}

export default Simon;